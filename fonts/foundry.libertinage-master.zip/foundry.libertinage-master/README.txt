
FONTLOG.txt: the font design-oriented changelog
http://scripts.sil.org/OFL-FAQ_web#00e3bd04

Libertinage.sfd: the fontforge sfd sources
http://fontforge.sourceforge.net/sfdformat.html

Libertinage.svg: svg font sources
http://www.w3.org/TR/SVG/fonts.html

Libertinage.ttf: ttf font sources
http://www.truetype-typography.com/ttspec.htm

Libertinage.vfb: Fontlab database sources (opaque format)
http://www.fontlab.com

OFL-1.1.txt: copyright notice header + license
OFL-1.1-header.txt: license header for separate files
OFL-FAQ.txt: Frequently Asked Questions about the license and its collaboration model
http://scripts.sil.org/OFL


